﻿/** [!]. ABOUT
 * "CS-XAML Clock"
 * by Matthew T. Theroux
 * for BakerCollegeOnline CS4010
 * Module 06 Assignment 02 (#12)
 * under Joan Zito
 * -makes a clock through the colaboration of both XAML -and- C#.
 **/

/// [I]. HEAD
///  A] IMPORTS
using System;
using Xamarin.Forms;

///
namespace XamlClock { 
    ///
    public partial class XamlClockPage { 
        /// 
        public XamlClockPage() { 

            /// necessary for XAML
            InitializeComponent(); 

            /// On each 1 second, (forever).
            Device.StartTimer(TimeSpan.FromSeconds(1), OnTimerTick); 

        }// /cxtr
        
        /// [II]. BODY
        /// Update the time.
        bool OnTimerTick()
        { 
            DateTime dt = DateTime.Now; 
            timeLabel.Text = dt.ToString("T"); 
            dateLabel.Text = dt.ToString("D"); 
            return true; 
        }// /hdlr

        /// [III]. FOOT
    }// /cla 'XamlClockPage'
}// /ns 'XamlClock'
/// [EoF].